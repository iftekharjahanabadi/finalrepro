/*================= Typing Animation ============== */
/*var typed = new Typed(".typing",{
    Strings:["","web Designer","web Developer","Graphic Designer","YouTuber"],
    typespeed:100,
    Backspeed:60,
    loop:true
})
*/
